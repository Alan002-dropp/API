import express from "express";
import cors from "cors";

import ufRoutes from "./routes/uf";
import cidadeRoutes from "./routes/cidade";
import regiaoRoutes from "./routes/regiao";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/uf", ufRoutes);
app.use("/cidade", cidadeRoutes);
app.use("/regiao", regiaoRoutes);

app.listen(3000, () => {
  console.log("API rodando em http://localhost:3000");
});
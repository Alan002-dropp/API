import { Router } from "express";
import { db } from "../db";
import { uf } from "../db/schema";
import { v4 as uuidv4 } from "uuid";
import { eq } from "drizzle-orm";

const router = Router();

// CREATE
router.post("/", async (req, res) => {
  const { nome, sigla } = req.body;

  const novo = {
    id: uuidv4(),
    nome,
    sigla,
  };

  await db.insert(uf).values(novo);
  res.json(novo);
});

// READ
router.get("/", async (_, res) => {
  const data = await db.select().from(uf);
  res.json(data);
});

// UPDATE
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { nome, sigla } = req.body;

  await db.update(uf)
    .set({ nome, sigla })
    .where(eq(uf.id, id));

  res.json({ message: "Atualizado" });
});

// DELETE
router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(uf)
    .where(eq(uf.id, id));

  res.json({ message: "Deletado" });
});

export default router;
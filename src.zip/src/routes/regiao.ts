import { Router } from "express";
import { db } from "../db";
import { regiao } from "../db/schema";
import { v4 as uuidv4 } from "uuid";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/", async (req, res) => {
  const { nome, cidade_id } = req.body;

  const nova = {
    id: uuidv4(),
    nome,
    cidade_id,
  };

  await db.insert(regiao).values(nova);
  res.json(nova);
});

router.get("/", async (_, res) => {
  const data = await db.select().from(regiao);
  res.json(data);
});

router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { nome, cidade_id } = req.body;

  await db.update(regiao)
    .set({ nome, cidade_id })
    .where(eq(regiao.id, id));

  res.json({ message: "Atualizado" });
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(regiao)
    .where(eq(regiao.id, id));

  res.json({ message: "Deletado" });
});

export default router;
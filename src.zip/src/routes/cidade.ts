import { Router } from "express";
import { db } from "../db";
import { cidade } from "../db/schema";
import { v4 as uuidv4 } from "uuid";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/", async (req, res) => {
  const { nome, uf_id } = req.body;

  const nova = {
    id: uuidv4(),
    nome,
    uf_id,
  };

  await db.insert(cidade).values(nova);
  res.json(nova);
});

router.get("/", async (_, res) => {
  const data = await db.select().from(cidade);
  res.json(data);
});

router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { nome, uf_id } = req.body;

  await db.update(cidade)
    .set({ nome, uf_id })
    .where(eq(cidade.id, id));

  res.json({ message: "Atualizado" });
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  await db.delete(cidade)
    .where(eq(cidade.id, id));

  res.json({ message: "Deletado" });
});

export default router;